# Generated from mission_3.json by build_archive.py.
from core import arc, att_left, att_right, att_run, att_wait, hub, straight, turn
from pybricks.tools import wait

NAME = 'Миссия 3'
COLOR = 'BLACK'

def run():
    straight(550, speed=800)
    straight(-200, speed=800)
    turn(45, rate=360)
    straight(300, speed=800)
    turn(-45, rate=360)
    straight(490, speed=800)
    att_run(att_right, 800, -100)
