# Generated from mission_1.json by build_archive.py.
from core import arc, att_left, att_right, att_run, att_wait, hub, straight, turn
from pybricks.tools import wait

NAME = 'Маршрут OP'
COLOR = 'MAGENTA'

def run():
    straight(275, speed=100)
    turn(90, rate=90)
    straight(50, speed=100)
    turn(90, rate=90)
    straight(50, speed=100)
    turn(90, rate=90)
    straight(50, speed=100)
    turn(90, rate=90)
    straight(25, speed=100)
    turn(-180, rate=90)
    straight(225, speed=100)
