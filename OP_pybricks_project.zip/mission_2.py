# Generated from mission_2.json by build_archive.py.
from core import arc, att_left, att_right, att_run, att_wait, hub, straight, turn
from pybricks.tools import wait

NAME = 'route'
COLOR = 'MAGENTA'

def run():
    straight(825, speed=750)
