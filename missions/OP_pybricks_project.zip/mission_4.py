# Generated from mission_4.json by build_archive.py.
# Импортируются только те имена, которые миссия действительно вызывает.
from core import arc, att_right, att_run, beep, rush, straight, turn

NAME = 'Миссия 4 — маршрут 0–5'
COLOR = 'CYAN'

def run():
    rush(True)
    straight(920, speed=800)
    beep(880, 100)
    att_run(att_right, 300, 90)
    straight(-300, speed=800)
    turn(140, rate=360)
    straight(300, speed=800)
    turn(-90, rate=360)
    beep(880, 100)
    turn(110, rate=360)
    arc(100, 20, speed=800)
    straight(400, speed=800)
    turn(-90, rate=360)
    straight(500, speed=800)
    turn(-40, rate=360)
    beep(880, 100)
    turn(40, rate=360)
    straight(-700, speed=300)
