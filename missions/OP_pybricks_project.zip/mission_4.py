# Generated from mission_4.json by build_archive.py.
# Импортируются только те имена, которые миссия действительно вызывает.
from core import att_right, att_run, beep, rush, straight, turn

NAME = 'Миссия 4 — маршрут 0–5'
COLOR = 'CYAN'

def run():
    rush(True)
    straight(920, speed=800)
    beep(880, 100)
    att_run(att_right, 300, 90)
    straight(-300, speed=800)
    turn(140, rate=360)
    straight(300, speed=800)
    turn(-90, rate=360)
    beep(880, 100)
    turn(130, rate=360)
    straight(450, speed=800)
    turn(-90, rate=360)
    straight(500, speed=800)
    turn(-40, rate=360)
    beep(880, 100)
    turn(40, rate=360)
    straight(-700, speed=300)
