# Generated from mission_2.json by build_archive.py.
# Импортируются только те имена, которые миссия действительно вызывает.
from core import att_right, att_run, straight

NAME = 'route'
COLOR = 'MAGENTA'

def run():
    straight(810, speed=800)
    att_run(att_right, 800, 80)
    att_run(att_right, 800, -90)
    straight(-100, speed=800)
    att_run(att_right, 800, 40)
    straight(90, speed=800)
    att_run(att_right, 800, 100)
