from system_check import (
    COLOR as _system_check_color,
    NAME as _system_check_name,
    run as _system_check_run,
)

# JSON-миссии из missions/*.json build_archive.py подставляет в этот каталог
# при сборке архива, поэтому в исходнике их нет.
from mission_1 import (
    COLOR as _mission_1_color,
    NAME as _mission_1_name,
    run as _mission_1_run,
)
from mission_2 import (
    COLOR as _mission_2_color,
    NAME as _mission_2_name,
    run as _mission_2_run,
)
from mission_3 import (
    COLOR as _mission_3_color,
    NAME as _mission_3_name,
    run as _mission_3_run,
)
from mission_4 import (
    COLOR as _mission_4_color,
    NAME as _mission_4_name,
    run as _mission_4_run,
)
from mission_5 import (
    COLOR as _mission_5_color,
    NAME as _mission_5_name,
    run as _mission_5_run,
)
from mission_6 import (
    COLOR as _mission_6_color,
    NAME as _mission_6_name,
    run as _mission_6_run,
)

MISSION_MODULES = (
    ('mission_1', _mission_1_name, _mission_1_run, _mission_1_color),
    ('mission_2', _mission_2_name, _mission_2_run, _mission_2_color),
    ('mission_3', _mission_3_name, _mission_3_run, _mission_3_color),
    ('mission_4', _mission_4_name, _mission_4_run, _mission_4_color),
    ('mission_5', _mission_5_name, _mission_5_run, _mission_5_color),
    ('mission_6', _mission_6_name, _mission_6_run, _mission_6_color),
)

TEST_MODULES = (
    ('system_check', _system_check_name, _system_check_run, _system_check_color),
)
