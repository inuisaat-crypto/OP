# Generated from mission_3.json by build_archive.py.
# Импортируются только те имена, которые миссия действительно вызывает.
from core import arc, att_right, att_run, att_wait, straight, turn

NAME = 'Миссия 3'
COLOR = 'BLACK'

def run():
    straight(550, speed=800)
    straight(-200, speed=800)
    turn(60, rate=360)
    att_run(att_right, 800, 100, wait=False)
    arc(-350, 60, speed=800)
    att_wait(att_right)
    straight(230, speed=800)
