# Generated from mission_6.json by build_archive.py.
# Импортируются только те имена, которые миссия действительно вызывает.
from core import arc, straight, turn
from pybricks.parameters import Stop

NAME = 'Новая миссия'
COLOR = 'WHITE'

def run():
    straight(600, speed=800, then=Stop.NONE)
    arc(200, 90, speed=800, then=Stop.NONE)
    straight(730, speed=800, then=Stop.NONE)
    arc(-200, 40, speed=300, then=Stop.NONE)
    straight(100, speed=250)
    straight(-100, speed=250)
    turn(90, rate=180)
    straight(500, speed=300, then=Stop.NONE)
    arc(200, 40, speed=800, then=Stop.NONE)
    straight(300, speed=300)
