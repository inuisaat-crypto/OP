# Generated from mission_1.json by build_archive.py.
# Импортируются только те имена, которые миссия действительно вызывает.
from core import beep

NAME = 'Маршрут OP'
COLOR = 'MAGENTA'

def run():
    beep(880, 100)
