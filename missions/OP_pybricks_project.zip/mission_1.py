# Generated from mission_1.json by build_archive.py.
# Импортируются только те имена, которые миссия действительно вызывает.
from core import straight, turn

NAME = 'Маршрут OP'
COLOR = 'MAGENTA'

def run():
    straight(280, speed=100)
    turn(90, rate=90)
    straight(50, speed=100)
    turn(90, rate=90)
    straight(50, speed=100)
    turn(90, rate=90)
    straight(50, speed=100)
    turn(90, rate=90)
    straight(30, speed=100)
    turn(-180, rate=90)
    straight(230, speed=100)
