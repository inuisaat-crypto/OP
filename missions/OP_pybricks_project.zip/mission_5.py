# Generated from mission_5.json by build_archive.py.
# Импортируются только те имена, которые миссия действительно вызывает.
from core import arc, straight, turn
from pybricks.parameters import Stop

NAME = 'Новая миссия'
COLOR = 'WHITE'

def run():
    straight(500, speed=800)
    straight(-200, speed=800, then=Stop.NONE)
    turn(90, rate=360, then=Stop.NONE)
    arc(-200, 90, speed=800, then=Stop.NONE)
    straight(300, speed=800)
    arc(200, -20, speed=800)
    straight(120, speed=800)
    arc(-500, -20, speed=800, then=Stop.NONE)
    straight(-600, speed=800)
